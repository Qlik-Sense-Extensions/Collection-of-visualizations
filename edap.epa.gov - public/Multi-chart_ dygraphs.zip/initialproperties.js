define([], function () {

    "use strict";

    return {
        version: 2.0,
        qHyperCubeDef : {
            qDimensions : [],
            qMeasures : [],
            qInitialDataFetch : [{
                qWidth : 100,
                qHeight : 100
            }]
        }
    };

});