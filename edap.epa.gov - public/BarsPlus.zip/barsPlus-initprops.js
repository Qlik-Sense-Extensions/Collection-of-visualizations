﻿define( [],
/**
* Initial properties
*/
function () {
	'use strict';
	return {
		qHyperCubeDef: {
			qDimensions: [],
			qMeasures: [],
			qInitialDataFetch: [
				{
					qWidth: 10,
					qHeight: 1000 // max qWidth*qHeight 10000
				}
			]
		}
	};
} );
